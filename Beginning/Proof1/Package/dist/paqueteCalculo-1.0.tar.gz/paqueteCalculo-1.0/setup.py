from setuptools import setup;

setup(
    name="paqueteCalculo",
    version="1.0",
    description="CalculosBasicos",
    author="Alejandro",
   
    
    author_email="Alejandro.molinar17@gmail.com",
    url="",
    packeges=["Package","Package.ProofBasic"]
    
    );
    
    
